import React from 'react'

const Organizationdiscussion = () => {
  return (
    <div>Organizationdiscussion</div>
  )
}

export default Organizationdiscussion