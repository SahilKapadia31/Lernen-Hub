import React from 'react'

export const Testimonials = () => {
    return (
        <div>Testimonials</div>
    )
}
