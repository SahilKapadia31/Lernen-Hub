import React from 'react'

export const Navbar = props => {
    return (
        <div>Navbar</div>
    )
}

