import React from 'react'

export const Features = () => {
    return (
        <div>Features</div>
    )
}
