import React from 'react'

export const HeroSection = () => {
    return (
        <div>HeroSection</div>
    )
}
